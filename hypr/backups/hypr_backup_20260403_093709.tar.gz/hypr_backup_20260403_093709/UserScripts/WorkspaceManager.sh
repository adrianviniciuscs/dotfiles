#!/bin/bash
# /* ---- 💼 Workspace Layout Manager ---- */ #
# Salva e restaura layouts de workspace (apps abertos em cada workspace)

LAYOUT_DIR="$HOME/.config/hypr/workspace_layouts"
mkdir -p "$LAYOUT_DIR"

# Função para salvar layout atual
save_layout() {
    local NAME="$1"
    if [ -z "$NAME" ]; then
        NAME=$(rofi -dmenu -p "Nome do layout:" -theme ~/.config/rofi/launchers/type-1/style-7.rasi)
        [ -z "$NAME" ] && exit 0
    fi
    
    LAYOUT_FILE="$LAYOUT_DIR/${NAME}.json"
    
    # Pega informações de todas as janelas
    hyprctl clients -j > "$LAYOUT_FILE"
    
    # Conta quantas janelas foram salvas
    COUNT=$(jq '. | length' "$LAYOUT_FILE")
    
    notify-send "💾 Layout Salvo" "Layout '$NAME' salvo\n$COUNT janelas capturadas"
}

# Função para restaurar layout
restore_layout() {
    local NAME="$1"
    if [ -z "$NAME" ]; then
        # Lista layouts disponíveis
        LAYOUTS=$(ls -1 "$LAYOUT_DIR"/*.json 2>/dev/null | xargs -n1 basename | sed 's/.json$//')
        if [ -z "$LAYOUTS" ]; then
            notify-send "⚠️ Workspace Manager" "Nenhum layout salvo ainda"
            exit 0
        fi
        
        NAME=$(echo "$LAYOUTS" | rofi -dmenu -p "Restaurar layout:" -theme ~/.config/rofi/launchers/type-1/style-7.rasi)
        [ -z "$NAME" ] && exit 0
    fi
    
    LAYOUT_FILE="$LAYOUT_DIR/${NAME}.json"
    
    if [ ! -f "$LAYOUT_FILE" ]; then
        notify-send -u critical "❌ Erro" "Layout '$NAME' não encontrado"
        exit 1
    fi
    
    notify-send "🔄 Restaurando Layout" "Layout '$NAME' sendo restaurado..."
    
    # Extrai apps por workspace e abre
    RESTORED=0
    while IFS= read -r line; do
        WORKSPACE=$(echo "$line" | jq -r '.workspace.id')
        CLASS=$(echo "$line" | jq -r '.class')
        
        # Tenta abrir app no workspace correto
        case "$CLASS" in
            "firefox"|"Firefox")
                hyprctl dispatch workspace "$WORKSPACE" && firefox &
                ((RESTORED++))
                ;;
            "code"|"Code")
                hyprctl dispatch workspace "$WORKSPACE" && code &
                ((RESTORED++))
                ;;
            "kitty"|"Alacritty")
                hyprctl dispatch workspace "$WORKSPACE" && kitty &
                ((RESTORED++))
                ;;
            "Spotify"|"spotify")
                hyprctl dispatch workspace "$WORKSPACE" && spotify &
                ((RESTORED++))
                ;;
        esac
        
        sleep 0.5 # Delay entre apps
    done < <(jq -c '.[]' "$LAYOUT_FILE")
    
    notify-send "✅ Layout Restaurado" "$RESTORED aplicações iniciadas"
}

# Função para listar layouts
list_layouts() {
    LAYOUTS=$(ls -1 "$LAYOUT_DIR"/*.json 2>/dev/null | xargs -n1 basename | sed 's/.json$//')
    if [ -z "$LAYOUTS" ]; then
        echo "Nenhum layout salvo"
    else
        echo "Layouts salvos:"
        echo "$LAYOUTS"
    fi
}

# Menu principal
case "$1" in
    save)
        save_layout "$2"
        ;;
    restore)
        restore_layout "$2"
        ;;
    list)
        list_layouts
        ;;
    *)
        # Menu interativo
        CHOICE=$(echo -e "💾 Salvar Layout Atual\n🔄 Restaurar Layout\n📋 Listar Layouts" | rofi -dmenu -p "Workspace Manager:" -theme ~/.config/rofi/launchers/type-1/style-7.rasi)
        
        case "$CHOICE" in
            *"Salvar"*)
                save_layout
                ;;
            *"Restaurar"*)
                restore_layout
                ;;
            *"Listar"*)
                list_layouts | rofi -dmenu -p "Layouts disponíveis:" -theme ~/.config/rofi/launchers/type-1/style-7.rasi
                ;;
        esac
        ;;
esac

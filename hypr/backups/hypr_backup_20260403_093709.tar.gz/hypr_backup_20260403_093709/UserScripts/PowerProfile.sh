#!/bin/bash
# /* ---- ⚡ Power Profile Switcher ---- */ #
# Alterna entre performance, balanced e power-saver

# Verifica se powerprofilesctl está disponível
if ! command -v powerprofilesctl &> /dev/null; then
    notify-send -u critical "Power Profile" "powerprofilesctl não instalado!"
    exit 1
fi

# Pega o modo atual
CURRENT=$(powerprofilesctl get)

# Alterna para o próximo modo
case "$CURRENT" in
    "performance")
        powerprofilesctl set balanced
        NEW="Balanced ⚖️"
        ICON="🔋"
        ;;
    "balanced")
        powerprofilesctl set power-saver
        NEW="Power Saver 🌱"
        ICON="🪫"
        ;;
    "power-saver")
        powerprofilesctl set performance
        NEW="Performance 🚀"
        ICON="⚡"
        ;;
    *)
        powerprofilesctl set balanced
        NEW="Balanced ⚖️"
        ICON="🔋"
        ;;
esac

# Notifica a mudança
notify-send -i power-profile-$NEW "$ICON Power Profile" "Mudado para: $NEW"

#!/bin/bash
# /* ---- 🚀 Quick Launch - Launcher de Apps Rápido ---- */ #
# Menu rofi customizado com apps mais usados + histórico

HISTORY_FILE="$HOME/.config/hypr/.app_history"
touch "$HISTORY_FILE"

# Apps favoritos (customiza aqui)
FAVORITES=(
    "🌐 Firefox|firefox"
    "💻 VS Code|code"
    "📝 Obsidian|flatpak run md.obsidian.Obsidian"
    "🎵 Spotify|spotify"
    "📁 Files|nautilus"
    "🖼️ GIMP|gimp"
    "🎬 VLC|vlc"
    "📧 Thunderbird|thunderbird"
    "💬 Discord|discord"
    "🔒 KeePass|keepassxc"
)

# Constrói lista de apps
APP_LIST=""
for app in "${FAVORITES[@]}"; do
    APP_LIST+="$(echo "$app" | cut -d'|' -f1)\n"
done

# Adiciona apps do histórico (últimos 5)
if [ -f "$HISTORY_FILE" ]; then
    RECENT=$(tail -5 "$HISTORY_FILE" | tac | awk '!seen[$0]++')
    if [ -n "$RECENT" ]; then
        APP_LIST+="────────────────\n"
        while IFS= read -r line; do
            APP_LIST+="🕐 $line\n"
        done <<< "$RECENT"
    fi
fi

# Mostra menu
SELECTED=$(echo -e "$APP_LIST" | rofi -dmenu -i -p "Lançar aplicação:" \
    -theme ~/.config/rofi/launchers/type-1/style-7.rasi)

if [ -n "$SELECTED" ]; then
    # Remove emoji e espaços extras
    CLEAN_NAME=$(echo "$SELECTED" | sed 's/^[🌐💻📝🎵📁🖼️🎬📧💬🔒🕐] //')
    
    # Encontra comando correspondente
    for app in "${FAVORITES[@]}"; do
        NAME=$(echo "$app" | cut -d'|' -f1 | sed 's/^[🌐💻📝🎵📁🖼️🎬📧💬🔒] //')
        CMD=$(echo "$app" | cut -d'|' -f2)
        
        if [ "$CLEAN_NAME" = "$NAME" ]; then
            # Salva no histórico
            echo "$NAME" >> "$HISTORY_FILE"
            
            # Executa
            eval "$CMD" &
            notify-send "🚀 Lançando" "$NAME"
            exit 0
        fi
    done
    
    # Se não encontrou nos favoritos, tenta executar diretamente
    if command -v "$CLEAN_NAME" &> /dev/null; then
        echo "$CLEAN_NAME" >> "$HISTORY_FILE"
        $CLEAN_NAME &
        notify-send "🚀 Lançando" "$CLEAN_NAME"
    fi
fi

#!/bin/bash
# /* ---- 🎯 Focus Mode - Produtividade Máxima ---- */ #
# Ativa/desativa modo foco: esconde waybar, pausa notificações, dimeia janelas inativas

STATE_FILE="/tmp/focus_mode_${USER}.state"

if [ -f "$STATE_FILE" ]; then
    # DESATIVAR modo foco
    
    # Restaura waybar
    killall -SIGUSR1 waybar 2>/dev/null
    
    # Reativa notificações
    swaync-client -R
    
    # Remove dim das janelas inativas
    hyprctl keyword decoration:dim_inactive false
    hyprctl keyword decoration:dim_strength 0.0
    
    # Remove arquivo de estado
    rm -f "$STATE_FILE"
    
    notify-send -t 3000 "🎯 Modo Foco" "Desativado - Bem-vindo de volta!"
    
else
    # ATIVAR modo foco
    
    # Esconde waybar
    killall -SIGUSR2 waybar 2>/dev/null
    
    # Pausa notificações
    swaync-client -d -sw
    
    # Dimeia janelas inativas (reduz distração)
    hyprctl keyword decoration:dim_inactive true
    hyprctl keyword decoration:dim_strength 0.4
    
    # Cria arquivo de estado
    touch "$STATE_FILE"
    
    notify-send -t 5000 -u critical "🎯 Modo Foco ATIVADO" "Notificações pausadas\nWaybar escondida\nJanelas inativas dimmed\n\nBoa produtividade! 🚀"
fi

#!/bin/bash
# /* ---- 📸 Screenshot OCR - Extrai texto de imagens ---- */ #
# Tira screenshot de uma área e extrai o texto com OCR

# Dependências: grim, slurp, tesseract, wl-clipboard
DEPS=("grim" "slurp" "tesseract" "wl-copy")
for dep in "${DEPS[@]}"; do
    if ! command -v "$dep" &> /dev/null; then
        notify-send -u critical "Screenshot OCR" "Faltando: $dep\nInstale com: sudo apt install ${dep/wl-copy/wl-clipboard}"
        exit 1
    fi
done

# Diretório temporário
TEMP_DIR="/tmp/screenshot_ocr_${USER}"
mkdir -p "$TEMP_DIR"
SCREENSHOT="$TEMP_DIR/screenshot.png"
TEXT_FILE="$TEMP_DIR/extracted_text.txt"

# Notifica início
notify-send -t 2000 "📸 Screenshot OCR" "Selecione a área com o mouse..."

# Captura área selecionada
if grim -g "$(slurp)" "$SCREENSHOT" 2>/dev/null; then
    
    # Processa OCR (português brasileiro)
    notify-send -t 2000 "🔍 Processando OCR..." "Extraindo texto..."
    
    if tesseract "$SCREENSHOT" "$TEMP_DIR/extracted_text" -l por 2>/dev/null; then
        
        # Lê o texto extraído
        EXTRACTED_TEXT=$(cat "$TEXT_FILE")
        
        if [ -n "$EXTRACTED_TEXT" ]; then
            # Copia para clipboard
            echo "$EXTRACTED_TEXT" | wl-copy
            
            # Conta palavras
            WORD_COUNT=$(echo "$EXTRACTED_TEXT" | wc -w)
            
            notify-send -t 5000 "✅ Texto Extraído!" "$WORD_COUNT palavras copiadas para clipboard\n\nPrimeiras linhas:\n${EXTRACTED_TEXT:0:100}..."
            
            # Opcional: salva em arquivo permanente
            SAVE_DIR="$HOME/Documents/OCR"
            mkdir -p "$SAVE_DIR"
            TIMESTAMP=$(date +%Y%m%d_%H%M%S)
            cp "$TEXT_FILE" "$SAVE_DIR/ocr_$TIMESTAMP.txt"
        else
            notify-send -u normal "⚠️ OCR" "Nenhum texto encontrado na imagem"
        fi
    else
        notify-send -u critical "❌ Erro OCR" "Falha ao processar imagem"
    fi
    
    # Limpa arquivos temporários
    rm -f "$SCREENSHOT" "$TEXT_FILE"
else
    notify-send -u normal "Screenshot OCR" "Cancelado"
fi

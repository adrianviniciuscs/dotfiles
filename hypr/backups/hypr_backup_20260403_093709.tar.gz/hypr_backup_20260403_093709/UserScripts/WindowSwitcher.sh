#!/bin/bash
# /* ---- 🪟 Smart Window Switcher with Preview ---- */ #
# Alternar entre janelas com preview visual usando rofi

# Pega lista de janelas com informações
WINDOWS=$(hyprctl clients -j)

# Formata para rofi (mostra título, classe e workspace)
WINDOW_LIST=$(echo "$WINDOWS" | jq -r '.[] | "\(.title) [\(.class)] - WS:\(.workspace.id) - ID:\(.address)"')

if [ -z "$WINDOW_LIST" ]; then
    notify-send "🪟 Window Switcher" "Nenhuma janela aberta"
    exit 0
fi

# Mostra menu rofi
SELECTED=$(echo "$WINDOW_LIST" | rofi -dmenu -i -p "Alternar para janela:" \
    -theme ~/.config/rofi/launchers/type-1/style-7.rasi \
    -format 's' -no-custom)

if [ -n "$SELECTED" ]; then
    # Extrai o ID (address) da janela selecionada
    WINDOW_ID=$(echo "$SELECTED" | grep -oP 'ID:\K0x[0-9a-f]+')
    
    if [ -n "$WINDOW_ID" ]; then
        # Foca na janela selecionada
        hyprctl dispatch focuswindow "address:$WINDOW_ID"
    fi
fi

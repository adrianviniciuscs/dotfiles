#!/bin/bash
# /* ---- 📊 System Monitor - Dashboard Rápido ---- */ #
# Mostra informações do sistema em notificação ou rofi

# Função para formatar bytes
format_bytes() {
    local bytes=$1
    if [ "$bytes" -ge 1073741824 ]; then
        echo "$(awk "BEGIN {printf \"%.1f\", $bytes/1073741824}")GB"
    elif [ "$bytes" -ge 1048576 ]; then
        echo "$(awk "BEGIN {printf \"%.1f\", $bytes/1048576}")MB"
    else
        echo "$(awk "BEGIN {printf \"%.1f\", $bytes/1024}")KB"
    fi
}

# CPU
CPU_USAGE=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | cut -d'%' -f1)
CPU_TEMP=$(sensors 2>/dev/null | grep -i 'Core 0' | awk '{print $3}' | head -1 | tr -d '+')
[ -z "$CPU_TEMP" ] && CPU_TEMP="N/A"

# Memória
MEM_TOTAL=$(free -b | awk '/^Mem:/ {print $2}')
MEM_USED=$(free -b | awk '/^Mem:/ {print $3}')
MEM_PERCENT=$(awk "BEGIN {printf \"%.1f\", ($MEM_USED/$MEM_TOTAL)*100}")
MEM_TOTAL_FMT=$(format_bytes "$MEM_TOTAL")
MEM_USED_FMT=$(format_bytes "$MEM_USED")

# Swap
SWAP_TOTAL=$(free -b | awk '/^Swap:/ {print $2}')
SWAP_USED=$(free -b | awk '/^Swap:/ {print $3}')
if [ "$SWAP_TOTAL" -gt 0 ]; then
    SWAP_PERCENT=$(awk "BEGIN {printf \"%.1f\", ($SWAP_USED/$SWAP_TOTAL)*100}")
    SWAP_TOTAL_FMT=$(format_bytes "$SWAP_TOTAL")
    SWAP_USED_FMT=$(format_bytes "$SWAP_USED")
else
    SWAP_PERCENT="0"
    SWAP_TOTAL_FMT="N/A"
    SWAP_USED_FMT="0"
fi

# Disco
DISK_USAGE=$(df -h / | awk 'NR==2 {print $5}' | tr -d '%')
DISK_USED=$(df -h / | awk 'NR==2 {print $3}')
DISK_TOTAL=$(df -h / | awk 'NR==2 {print $2}')

# Bateria (se disponível)
if [ -d /sys/class/power_supply/BAT0 ]; then
    BATTERY=$(cat /sys/class/power_supply/BAT0/capacity 2>/dev/null)
    BATTERY_STATUS=$(cat /sys/class/power_supply/BAT0/status 2>/dev/null)
    BATTERY_INFO="🔋 Bateria: $BATTERY% ($BATTERY_STATUS)"
else
    BATTERY_INFO="🔌 Desktop (sem bateria)"
fi

# Uptime
UPTIME=$(uptime -p | sed 's/up //')

# Power Profile
if command -v powerprofilesctl &> /dev/null; then
    POWER_PROFILE=$(powerprofilesctl get)
else
    POWER_PROFILE="N/A"
fi

# Monta mensagem
MESSAGE="📊 SYSTEM MONITOR

🖥️  CPU: ${CPU_USAGE}% | Temp: $CPU_TEMP
🧠 RAM: ${MEM_USED_FMT}/${MEM_TOTAL_FMT} (${MEM_PERCENT}%)
💾 Swap: ${SWAP_USED_FMT}/${SWAP_TOTAL_FMT} (${SWAP_PERCENT}%)
💿 Disco /: ${DISK_USED}/${DISK_TOTAL} (${DISK_USAGE}%)
$BATTERY_INFO
⚡ Power: $POWER_PROFILE
⏰ Uptime: $UPTIME"

# Verifica alertas
ALERTS=""
if (( $(echo "$CPU_USAGE > 80" | bc -l) )); then
    ALERTS+="⚠️  CPU acima de 80%!\n"
fi
if (( $(echo "$MEM_PERCENT > 80" | bc -l) )); then
    ALERTS+="⚠️  RAM acima de 80%!\n"
fi
if (( $(echo "$SWAP_PERCENT > 50" | bc -l) )); then
    ALERTS+="⚠️  Swap acima de 50%!\n"
fi
if (( $(echo "$DISK_USAGE > 85" | bc -l) )); then
    ALERTS+="⚠️  Disco acima de 85%!\n"
fi

if [ -n "$ALERTS" ]; then
    MESSAGE+="\n\n🚨 ALERTAS:\n$ALERTS"
    URGENCY="critical"
else
    URGENCY="normal"
fi

# Mostra notificação
notify-send -u "$URGENCY" -t 10000 "System Monitor" "$MESSAGE"

# Também imprime no terminal se chamado diretamente
echo -e "$MESSAGE"

#!/bin/bash
# /* ---- 💾 Config Backup Manager ---- */ #
# Backup automático da configuração do Hyprland com versionamento

BACKUP_DIR="$HOME/.config/hypr/backups"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_NAME="hypr_backup_$TIMESTAMP"
BACKUP_PATH="$BACKUP_DIR/$BACKUP_NAME"

# Cria diretório de backup
mkdir -p "$BACKUP_DIR"

# Cria backup
notify-send "💾 Backup" "Criando backup da config..."

# Copia configuração atual
mkdir -p "$BACKUP_PATH"
cp -r ~/.config/hypr/*.conf "$BACKUP_PATH/" 2>/dev/null
cp -r ~/.config/hypr/UserConfigs "$BACKUP_PATH/" 2>/dev/null
cp -r ~/.config/hypr/UserScripts "$BACKUP_PATH/" 2>/dev/null
cp -r ~/.config/hypr/configs "$BACKUP_PATH/" 2>/dev/null
cp -r ~/.config/hypr/scripts "$BACKUP_PATH/" 2>/dev/null

# Compacta backup
cd "$BACKUP_DIR" || exit 1
tar -czf "${BACKUP_NAME}.tar.gz" "$BACKUP_NAME" 2>/dev/null
rm -rf "$BACKUP_PATH"

# Calcula tamanho
SIZE=$(du -h "${BACKUP_NAME}.tar.gz" | cut -f1)

# Remove backups antigos (mantém últimos 10)
BACKUP_COUNT=$(ls -1 "$BACKUP_DIR"/hypr_backup_*.tar.gz 2>/dev/null | wc -l)
if [ "$BACKUP_COUNT" -gt 10 ]; then
    ls -1t "$BACKUP_DIR"/hypr_backup_*.tar.gz | tail -n +11 | xargs rm -f
    REMOVED=$((BACKUP_COUNT - 10))
    notify-send "🗑️ Limpeza" "Removidos $REMOVED backups antigos"
fi

notify-send "✅ Backup Completo" "Salvo: $BACKUP_NAME.tar.gz\nTamanho: $SIZE\n\nLocalização: $BACKUP_DIR"

# Lista backups disponíveis
echo "Backups disponíveis:"
ls -1th "$BACKUP_DIR"/hypr_backup_*.tar.gz 2>/dev/null | head -10
